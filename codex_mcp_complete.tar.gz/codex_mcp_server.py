#!/usr/bin/env python3
"""
Codex MCP Server - The Enforcer
Dual-agent system for pristine code quality enforcement
Russian Olympic Judge Standard: 10.0 or GTFO
"""

import json
import os
import re
import subprocess
import hashlib
import asyncio
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
import mcp.server as mcp
from mcp.server.stdio import stdio_server

@dataclass
class CodexSnapshot:
    """Snapshot of code state for comparison"""
    timestamp: str
    files: Dict[str, str]  # filepath -> content hash
    file_contents: Dict[str, str]  # filepath -> actual content
    metadata: Dict[str, Any]

@dataclass
class CodexReport:
    """Enforcement report with Russian Olympic Judge scoring"""
    score: float
    issues: List[str]
    fixes_applied: List[str]
    files_modified: List[str]
    timestamp: str
    pristine: bool  # True if score >= 9.0

class CodexEnforcer:
    """The Enforcer - Maintains pristine code quality"""
    
    def __init__(self):
        self.snapshot: Optional[CodexSnapshot] = None
        self.workspace_root = Path.cwd()
        
    def calculate_hash(self, content: str) -> str:
        """Calculate SHA-256 hash of content"""
        return hashlib.sha256(content.encode()).hexdigest()
    
    def remove_debug_statements(self, content: str, file_type: str) -> Tuple[str, int]:
        """Remove all debug statements from code"""
        removed_count = 0
        
        if file_type in ['.py', '.python']:
            # Remove Python debug statements
            patterns = [
                r'^\s*print\s*\([^)]*\)\s*(?:#.*)?$',
                r'^\s*console\.log\s*\([^)]*\)\s*;?\s*(?:#.*)?$',
                r'^\s*#\s*DEBUG:.*$',
                r'^\s*#\s*TODO:.*$',  # Optional: remove TODOs
            ]
            for pattern in patterns:
                matches = re.findall(pattern, content, re.MULTILINE)
                removed_count += len(matches)
                content = re.sub(pattern, '', content, flags=re.MULTILINE)
                
        elif file_type in ['.js', '.jsx', '.ts', '.tsx']:
            # Remove JavaScript/TypeScript debug statements
            patterns = [
                r'^\s*console\.(log|debug|info|warn|error)\s*\([^)]*\)\s*;?\s*(?://.*)?$',
                r'^\s*debugger\s*;?\s*$',
                r'^\s*//\s*DEBUG:.*$',
                r'^\s*//\s*TODO:.*$',
            ]
            for pattern in patterns:
                matches = re.findall(pattern, content, re.MULTILINE)
                removed_count += len(matches)
                content = re.sub(pattern, '', content, flags=re.MULTILINE)
        
        # Remove multiple consecutive blank lines
        content = re.sub(r'\n\s*\n\s*\n', '\n\n', content)
        
        return content, removed_count
    
    def remove_dead_code(self, content: str, file_type: str) -> Tuple[str, int]:
        """Remove commented-out code blocks"""
        removed_count = 0
        
        # Remove large commented blocks (3+ consecutive comment lines)
        if file_type in ['.py', '.python']:
            pattern = r'(^\s*#[^#].*\n){3,}'
            matches = re.findall(pattern, content, re.MULTILINE)
            removed_count += len(matches)
            content = re.sub(pattern, '', content, flags=re.MULTILINE)
            
        elif file_type in ['.js', '.jsx', '.ts', '.tsx']:
            # Remove block comments
            pattern = r'/\*[\s\S]*?\*/'
            matches = re.findall(pattern, content)
            removed_count += len(matches)
            content = re.sub(pattern, '', content)
            
            # Remove consecutive line comments
            pattern = r'(^\s*//.*\n){3,}'
            matches = re.findall(pattern, content, re.MULTILINE)
            removed_count += len(matches)
            content = re.sub(pattern, '', content, flags=re.MULTILINE)
        
        return content, removed_count
    
    def check_file_length(self, content: str, filepath: str) -> List[str]:
        """Check if file exceeds 500 lines"""
        issues = []
        lines = content.split('\n')
        if len(lines) > 500:
            issues.append(f"File {filepath} has {len(lines)} lines (exceeds 500 line limit)")
        return issues
    
    def score_code_quality(self, issues: List[str], fixes: List[str]) -> float:
        """
        Russian Olympic Judge Scoring
        10.0 = Perfect, zero flaws
        9.5-9.9 = Excellent, minor style issues only
        9.0-9.4 = Very good, small issues
        8.0-8.9 = Good, some cleanup needed
        <9.0 = NOT pristine, must fix
        """
        if not issues and not fixes:
            return 10.0
        
        score = 10.0
        
        # Deduct for issues found
        for issue in issues:
            if "exceeds 500 line" in issue:
                score -= 0.5
            elif "debug statement" in issue.lower():
                score -= 0.2
            elif "dead code" in issue.lower():
                score -= 0.3
            elif "missing docstring" in issue.lower():
                score -= 0.1
            else:
                score -= 0.1
        
        # Bonus for fixes applied
        if len(fixes) > 0:
            score += min(0.2, len(fixes) * 0.05)
        
        return max(0.0, min(10.0, score))
    
    async def take_snapshot(self, paths: List[str]) -> CodexSnapshot:
        """Take pristine snapshot of specified files"""
        snapshot_files = {}
        file_contents = {}
        
        for path in paths:
            filepath = Path(path)
            if filepath.exists() and filepath.is_file():
                content = filepath.read_text(encoding='utf-8')
                snapshot_files[str(filepath)] = self.calculate_hash(content)
                file_contents[str(filepath)] = content
        
        snapshot = CodexSnapshot(
            timestamp=datetime.now().isoformat(),
            files=snapshot_files,
            file_contents=file_contents,
            metadata={
                "workspace": str(self.workspace_root),
                "file_count": len(snapshot_files)
            }
        )
        
        self.snapshot = snapshot
        return snapshot
    
    async def enforce_quality(self, paths: List[str], auto_fix: bool = True) -> CodexReport:
        """Enforce code quality standards on specified files"""
        issues = []
        fixes_applied = []
        files_modified = []
        
        for path in paths:
            filepath = Path(path)
            if not filepath.exists():
                issues.append(f"File not found: {path}")
                continue
            
            content = filepath.read_text(encoding='utf-8')
            original_content = content
            file_ext = filepath.suffix
            
            # Check file length
            length_issues = self.check_file_length(content, path)
            issues.extend(length_issues)
            
            if auto_fix:
                # Remove debug statements
                content, debug_removed = self.remove_debug_statements(content, file_ext)
                if debug_removed > 0:
                    fixes_applied.append(f"Removed {debug_removed} debug statements from {path}")
                
                # Remove dead code
                content, dead_removed = self.remove_dead_code(content, file_ext)
                if dead_removed > 0:
                    fixes_applied.append(f"Removed {dead_removed} dead code blocks from {path}")
                
                # Write back if modified
                if content != original_content:
                    filepath.write_text(content, encoding='utf-8')
                    files_modified.append(path)
        
        # Calculate score
        score = self.score_code_quality(issues, fixes_applied)
        
        report = CodexReport(
            score=score,
            issues=issues,
            fixes_applied=fixes_applied,
            files_modified=files_modified,
            timestamp=datetime.now().isoformat(),
            pristine=score >= 9.0
        )
        
        return report

# Initialize server and enforcer
server = mcp.Server("codex-enforcer")
enforcer = CodexEnforcer()

@server.list_tools()
async def list_tools():
    return [
        mcp.Tool(
            name="codex_snapshot",
            description="Take pristine snapshot of specified files for later comparison",
            inputSchema={
                "type": "object",
                "properties": {
                    "paths": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of file paths to snapshot"
                    }
                },
                "required": ["paths"]
            }
        ),
        mcp.Tool(
            name="codex_enforce",
            description="Enforce code quality standards and clean up code",
            inputSchema={
                "type": "object",
                "properties": {
                    "paths": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of file paths to enforce"
                    },
                    "auto_fix": {
                        "type": "boolean",
                        "description": "Automatically apply fixes",
                        "default": True
                    }
                },
                "required": ["paths"]
            }
        ),
        mcp.Tool(
            name="codex_validate",
            description="Validate code meets pristine standards (9.0+ score required)",
            inputSchema={
                "type": "object",
                "properties": {
                    "paths": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Files to validate"
                    }
                },
                "required": ["paths"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]):
    if name == "codex_snapshot":
        snapshot = await enforcer.take_snapshot(arguments["paths"])
        return [mcp.TextContent(
            type="text",
            text=json.dumps({
                "status": "snapshot_taken",
                "timestamp": snapshot.timestamp,
                "files_captured": len(snapshot.files),
                "files": list(snapshot.files.keys())
            }, indent=2)
        )]
    
    elif name == "codex_enforce":
        report = await enforcer.enforce_quality(
            arguments["paths"],
            arguments.get("auto_fix", True)
        )
        return [mcp.TextContent(
            type="text",
            text=json.dumps({
                "score": report.score,
                "pristine": report.pristine,
                "issues": report.issues,
                "fixes_applied": report.fixes_applied,
                "files_modified": report.files_modified,
                "recommendation": "APPROVED ✅" if report.pristine else "NEEDS WORK ❌"
            }, indent=2)
        )]
    
    elif name == "codex_validate":
        report = await enforcer.enforce_quality(
            arguments["paths"],
            auto_fix=False  # Just validate, don't fix
        )
        
        validation = {
            "score": report.score,
            "pristine": report.pristine,
            "status": "PASS ✅" if report.pristine else "FAIL ❌",
            "issues": report.issues,
            "required_score": 9.0,
            "recommendation": "Ready for production" if report.pristine else "Needs cleanup"
        }
        
        return [mcp.TextContent(
            type="text",
            text=json.dumps(validation, indent=2)
        )]
    
    return [mcp.TextContent(type="text", text=f"Unknown tool: {name}")]

async def main():
    """Run the MCP server"""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream)

if __name__ == "__main__":
    asyncio.run(main())
